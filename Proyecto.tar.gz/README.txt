Carpeta: WEB
Virtual environment: venv
Project: blogtube
Usuario: admin
Mail: nicolas.miranda@sansano.usm.cl
Password: admin123

-------------

App: video