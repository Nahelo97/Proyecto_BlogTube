# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.core.urlresolvers import reverse
from django.http.response import HttpResponseRedirect
from .models import Video, Categoria, Comentario
def vista_video(request):
	template='video/videos.html'
	data= dict()
	data['titulo']='Video del Día'
	data['vista_video']=Video.objects.all()
	data['categs']=Categoria.objects.all()
	return render(request,template,data)

"""def categs(request, id_cat):
	template='video/categs.html'
	data = dict()
	data['categoria']=Categoria-objects.get(pk=id_cat)
	data['videos'] = Video.objects.filter(categoria__nombre=data['categoria'].nombre)
	return render(request,template,data)"""
